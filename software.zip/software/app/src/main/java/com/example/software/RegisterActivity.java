package com.example.software;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;

import com.example.software.model.RegBean;
import com.example.software.presenter.RegPresenter;
import com.example.software.view.MyView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;



public class RegisterActivity extends AppCompatActivity  implements OnClickListener, MyView.RegView {
    private RegPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
        presenter = new RegPresenter(this);
    }
    @BindView(R.id.reg_et_pwd)
    EditText et_pwd;
    @BindView(R.id.reg_et_email)
    EditText et_email;
    @BindView(R.id.reg_et_pwd2)
    EditText et_pwd2;
    //@BindView(R.id.reg_et_val)
    //EditText et_code;
    @BindView(R.id.reg_bt_next)
    Button bt_next;
    //@BindView(R.id.reg_bt_send)
    //Button bt_send;
    @BindView(R.id.reg_bt_back)
    Button bt_back;

    @Override
    public void failed(int code) {
        Toast.makeText(this, "注册失败！请检查网络", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void success(RegBean regBean) {
        //Toast.makeText(this,regBean.getMsg(), Toast.LENGTH_SHORT).show();
        Log.d("调试","注册或者发验证码成了");
        Log.d("调试",regBean.getMsg());
        if(regBean.getMsg().equals("注册成功")){
            try {
                Thread.sleep(500);
                Toast.makeText(this, "即将跳转到登录页面", Toast.LENGTH_SHORT).show();
                finish();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        else if(regBean.getStatus()==0){
            Toast.makeText(this,"用户名已存在", Toast.LENGTH_SHORT).show();
        }
    }

    @OnClick({
            R.id.reg_bt_next,
            //R.id.reg_bt_send,
            R.id.reg_bt_back,
    })
    public void onClick(View view){
        switch(view.getId()){
            case R.id.reg_bt_next:
                String email = et_email.getText().toString();
                String password = et_pwd.getText().toString();
                String password2 = et_pwd2.getText().toString();
                String code ="123";
                //TODO:先检查2个密码是否一样
                if(!password.equals(password2)){
                    Toast.makeText(this, "两次输入的密码不符", Toast.LENGTH_SHORT).show();
                }

                // 直接发送请求

                if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password) && !TextUtils.isEmpty(password2) && !TextUtils.isEmpty(code) ){
                    presenter.getData(email, password, code,1);

                }
                else{
                    Toast.makeText(this, "所填信息不能为空", Toast.LENGTH_SHORT).show();
                }
                break;
                /*
            case R.id.reg_bt_send:
                //TODO:发送验证码,增加调用验证码的接口,还是RegBean

                String Email = et_email.getText().toString();
                Log.d("调试","Email验证码请求已发送");
                presenter.getData(Email,"123","default",0);
                break;
                */
            case R.id.reg_bt_back:
                finish();
                break;
        }
    }
}
