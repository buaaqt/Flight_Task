package com.example.software.model;
import com.example.software.model.FlightBean;
import com.example.software.model.LoginBean;
import com.example.software.model.RegBean;

import io.reactivex.Observable;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import java.util.*;

public interface GetDataInterface {
    //注册的接口
    //https://www.zhaoapi.cn/user/reg?mobile=18631090582&password=888888

    @GET("Register")
    Observable<RegBean> reg(@Query("account") String account,@Query("password") String password,@Query("verifycode") String verifycode,@Query("flag") int flag);

    //登录的接口
    //https://www.zhaoapi.cn/user/login?mobile=18631090582&password=888888

    @GET("Login")
    Observable<LoginBean> login(@Query("account") String account,@Query("password") String password);

    //查询航班接口：
    //https://www.zhaoapi.cn/user/getUserInfo?uid=100
    @GET("SearchMarkPlane")
    Observable<FlightBean> flight(@Query("departure") String departure,@Query("arrival") String arrival,@Query("number") String number,@Query("date") String date,@Query("account") String account,@Query("plane_id") String plane_id,@Query("flag") int flag);

    @GET("SearchMarkedCancel")
    Observable<MarkedBean> marked(@Query("account") String account,@Query("plane_id") String plane_id,@Query("flag") int flag);
}
