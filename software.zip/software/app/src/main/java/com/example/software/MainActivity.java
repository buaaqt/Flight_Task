package com.example.software;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import com.lljjcoder.style.citylist.utils.CityListLoader;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;
import com.lljjcoder.style.citylist.CityListSelectActivity;


public class MainActivity extends AppCompatActivity {

    private BottomNavigationView mBottomNavigationView;

    private int lastIndex;
    List<Fragment> mFragments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initBottomNavigation();
        initData();
        CityListLoader.getInstance().loadCityData(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        Log.d("调试","mainAct.onActRes");
        if(requestCode == CityListSelectActivity.CITY_SELECT_RESULT_FRAG){
            //Log.d("调试","mainAct.onActRes2");
            if(resultCode == RESULT_OK){
                //Log.d("调试","mainAct.onActRes3");

                //mFragments.get(0).onActivityResult(requestCode,resultCode,data);
            }
        }
    }


    public void initData() {
        mFragments = new ArrayList<>();
        mFragments.add(new ExploreFragment());
        mFragments.add(new InboxFragment());
        mFragments.add(new HomeFragment());
        // 初始化展示MessageFragment
        setFragmentPosition(0);
    }

    public void initBottomNavigation() {
        mBottomNavigationView = findViewById(R.id.navigation);
        // 解决当item大于三个时，非平均布局问题
        mBottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_explore:
                        setFragmentPosition(0);
                        break;
                    case R.id.menu_inbox:
                        setFragmentPosition(1);
                        break;
                    case R.id.menu_home:
                        setFragmentPosition(2);
                        break;
                    default:
                        break;
                }
                // 这里注意返回true,否则点击失效
                return true;
            }
        });
        mBottomNavigationView.setItemIconTintList(null);
    }


    private void setFragmentPosition(int position) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        Fragment currentFragment = mFragments.get(position);
        Fragment lastFragment = mFragments.get(lastIndex);
        lastIndex = position;
        ft.hide(lastFragment);
        if (!currentFragment.isAdded()) {
            getSupportFragmentManager().beginTransaction().remove(currentFragment).commit();
            //remove or hide
            ft.add(R.id.main_fl, currentFragment);
        }
        ft.show(currentFragment);
        ft.commitAllowingStateLoss();
    }
}