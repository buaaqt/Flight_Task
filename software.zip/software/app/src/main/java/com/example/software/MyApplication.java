package com.example.software;
import android.app.Application;
import android.view.View;

public class MyApplication extends Application{
    @Override
    public void onCreate(){
        super.onCreate();
    }
}
