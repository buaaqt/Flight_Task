package com.example.software.presenter;

import android.util.Log;

import com.example.software.model.ModelCallBack;
import com.example.software.view.MyView;
import com.example.software.model.RegBean;
import com.example.software.model.RegModel;

public class RegPresenter {
    RegModel regModel = new RegModel();
    MyView.RegView regView;
    public RegPresenter(MyView.RegView regView) {
        this.regView = regView;
    }

    public void getData(String tel, String pwd,String verifycode,int flag) {
        regModel.getRegData(tel,pwd, verifycode,flag,new ModelCallBack.RegCallBack() {

            @Override
            public void success(RegBean regBean) {
                regView.success(regBean);
                //System.out.println("注册p数据："+regBean.toString());
            }

            @Override
            public void failed(Throwable code) {
                Log.d("调试","Register failed");
                code.printStackTrace();
            }
        });
    }
}
