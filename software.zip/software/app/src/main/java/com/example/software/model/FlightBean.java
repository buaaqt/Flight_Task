package com.example.software.model;


import java.io.Serializable;
import java.util.List;

public class FlightBean implements Serializable {


    /**
     * status : 0
     * msg : none
     * data : [{"id":1,"number":"ok","departure":"ok","arrival":"ok","depart_time":"ok","arrive_time":"ok","spendtime":"ok","airline":"ok","price":"ok","delay":"ok","delay_rate":"ok","dpt_airport":"ok","arv_airport":"ok","merge_from":"ok","merge_to":"ok"}]
     */

    private int status;
    private String msg;
    public List<DataBean> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {

        private String id;
        private String number;
        private String departure;
        private String arrival;
        private String depart_time;
        private String arrive_time;
        private String spendtime;
        private String airline;
        private String price;
        private String delay;
        private String delay_rate;
        private String dpt_airport;
        private String arv_airport;
        private String merge_from;
        private String merge_to;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getDeparture() {
            return departure;
        }

        public void setDeparture(String departure) {
            this.departure = departure;
        }

        public String getArrival() {
            return arrival;
        }

        public void setArrival(String arrival) {
            this.arrival = arrival;
        }

        public String getDepart_time() {
            return depart_time;
        }

        public void setDepart_time(String depart_time) {
            this.depart_time = depart_time;
        }

        public String getArrive_time() {
            return arrive_time;
        }

        public void setArrive_time(String arrive_time) {
            this.arrive_time = arrive_time;
        }

        public String getSpendtime() {
            return spendtime;
        }

        public void setSpendtime(String spendtime) {
            this.spendtime = spendtime;
        }

        public String getAirline() {
            return airline;
        }

        public void setAirline(String airline) {
            this.airline = airline;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getDelay() {
            return delay;
        }

        public void setDelay(String delay) {
            this.delay = delay;
        }

        public String getDelay_rate() {
            return delay_rate;
        }

        public void setDelay_rate(String delay_rate) {
            this.delay_rate = delay_rate;
        }

        public String getDpt_airport() {
            return dpt_airport;
        }

        public void setDpt_airport(String dpt_airport) {
            this.dpt_airport = dpt_airport;
        }

        public String getArv_airport() {
            return arv_airport;
        }

        public void setArv_airport(String arv_airport) {
            this.arv_airport = arv_airport;
        }

        public String getMerge_from() {
            return merge_from;
        }

        public void setMerge_from(String merge_from) {
            this.merge_from = merge_from;
        }

        public String getMerge_to() {
            return merge_to;
        }

        public void setMerge_to(String merge_to) {
            this.merge_to = merge_to;
        }
    }
}
