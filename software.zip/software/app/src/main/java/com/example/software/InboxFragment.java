package com.example.software;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;

import com.example.software.view.MyView;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.example.software.model.FlightBean;
import com.google.gson.Gson;
import android.support.v7.widget.LinearLayoutManager;
import com.example.software.model.LoginBean;
import com.google.gson.reflect.TypeToken;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.widget.Toast;

import com.example.software.presenter.MarkedPresenter;
import com.example.software.model.MarkedBean;
import com.example.software.model.MarkedModel;

public class InboxFragment extends Fragment implements MyView.MarkedView {

    private View view;
    private RecyclerView recyclerView;
    private HistoricalAdapter adapter;
    private List<LoginBean.DataBean> list=new ArrayList<LoginBean.DataBean>();
    private MarkedPresenter presenter;
    private String identifier;

    public static InboxFragment newInstance(String param1, String param2) {
        InboxFragment fragment = new InboxFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.fragment_inbox, container, false);
        initData();
        initRecyclerView();
        presenter = new MarkedPresenter(this);
        return view;
    }


    private void initData(){
        //Log.d("调试","initData Start");
        list = new ArrayList<LoginBean.DataBean>();
        Gson gson = new Gson();
        SharedPreferences cache = this.getActivity().getSharedPreferences("cache",Context.MODE_WORLD_READABLE | Context.MODE_WORLD_WRITEABLE | Context.MODE_MULTI_PROCESS);
        String usr = cache.getString("Email","");
        String json = cache.getString(usr+"Flight",null);

        if(json!=null){
            //Log.d("调试",json);
            LoginBean save1 = gson.fromJson(json,new TypeToken<LoginBean>(){}.getType());
            list = save1.getData();

        }
        String json2 = cache.getString(usr+"Mark",null);
        if(json2!=null){
            //Log.d("调试",json2);
            //Log.d("调试","initData Step2");
            List<LoginBean.DataBean> save2 = gson.fromJson(json2,new TypeToken<List<LoginBean.DataBean>>(){}.getType());
            list.addAll(save2);
        }

        //Log.d("调试","initData Over");
    }

    private void initRecyclerView(){
        recyclerView=(RecyclerView)view.findViewById(R.id.collect_recyclerView);
        //创建adapter
        adapter = new HistoricalAdapter(getActivity(), (ArrayList)list);
        //给RecyclerView设置adapter
        recyclerView.setAdapter(adapter);
        //设置layoutManager,可以设置显示效果，是线性布局、grid布局，还是瀑布流布局
        //参数是：上下文、列表方向（横向还是纵向）、是否倒叙
        recyclerView.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getActivity()).build());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        //设置item的分割线
        //recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),DividerItemDecoration.VERTICAL));
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        adapter.buttonSetOnclick(new HistoricalAdapter.DeleteInterface() {
            @Override
            public void onclick(View view, int position, String id) {
                //TODO:先发请求，下面的放到success
                Log.d("调试","已发出删除请求");
                SharedPreferences cache = getActivity().getSharedPreferences("cache",Context.MODE_WORLD_READABLE | Context.MODE_WORLD_WRITEABLE | Context.MODE_MULTI_PROCESS);
                String usr = cache.getString("Email","");
                identifier = id;
                presenter.getData(usr,id,0);
            }
        });

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {  //不在最前端界面显示

        } else {  //重新显示到最前端
            initData();
            adapter.setList((ArrayList)list);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void success(MarkedBean markedBean) {
        Log.d("调试","删除成功");
        SharedPreferences cache = getActivity().getSharedPreferences("cache",getActivity().MODE_WORLD_READABLE | getActivity().MODE_WORLD_WRITEABLE | getActivity().MODE_MULTI_PROCESS);
        String usr = cache.getString("Email","");
        String json = cache.getString(usr+"Flight",null);
        Editor editor = cache.edit();
        Gson gson = new Gson();
        if(json!=null){
            LoginBean save1 = gson.fromJson(json,new TypeToken<LoginBean>(){}.getType());
            int i,flag=0;
            for(i=0;i<save1.getData().size();i++){
                if(save1.getData().get(i).getId().equals(identifier)){
                    flag = 1;
                    break;
                }
            }
            if(flag==1){
                save1.getData().remove(i);
                String newj1 = gson.toJson(save1);
                editor.putString(usr+"Flight",newj1);
                Log.d("调试","删除一个1");
                Log.d("调试",String.valueOf(save1.getData().size()));
            }
        }
        String json2 = cache.getString(usr+"Mark",null);
        if(json2!=null){
            List<LoginBean.DataBean> save2 = gson.fromJson(json2,new TypeToken<List<LoginBean.DataBean>>(){}.getType());
            int i,flag=0;
            for(i=0;i<save2.size();i++) {
                if (save2.get(i).getId().equals(identifier)) {
                    flag = 1;
                    break;
                }
            }
            if(flag==1){
                save2.remove(i);
                String newj2 = gson.toJson(save2);
                editor.putString(usr+"Mark",newj2);
                Log.d("调试","删除一个2");
                Log.d("调试",String.valueOf(save2.size()));
            }

        }
        editor.apply();
        initData();
        Log.d("调试","list size "+String.valueOf(list.size()));
        adapter.setList((ArrayList)list);
        adapter.notifyDataSetChanged();
        Log.d("调试","adapter改变");
    }
    @Override
    public void failed(int code) {
        Log.d("调试","删除失败");
        Toast.makeText(this.getActivity(), "删除失败", Toast.LENGTH_SHORT).show();
    }
}
