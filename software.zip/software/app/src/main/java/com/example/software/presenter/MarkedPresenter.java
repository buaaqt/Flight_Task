package com.example.software.presenter;

import com.example.software.model.MarkedBean;
import com.example.software.model.MarkedModel;
import com.example.software.model.ModelCallBack;
import com.example.software.view.MyView;

public class MarkedPresenter {
    MarkedModel markedModel = new MarkedModel();
    MyView.MarkedView markedView;
    public MarkedPresenter(MyView.MarkedView markedView) {
        this.markedView = markedView;
    }

    public void getData(String account,String plane_id,int flag) {
        markedModel.getMarkedData(account,plane_id,flag, new ModelCallBack.MarkedCallBack() {
            @Override
            public void success(MarkedBean markedBean) {
                markedView.success(markedBean);
                //System.out.println("航班p数据："+flightBean.toString());
            }

            @Override
            public void failed(Throwable code) {
                //System.out.println("航班p错误："+code);
            }
        });
    }
}
