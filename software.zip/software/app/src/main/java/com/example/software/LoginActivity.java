package com.example.software;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.example.software.model.LoginBean;
import com.example.software.presenter.LoginPresenter;
import com.example.software.view.MyView;
import com.google.gson.Gson;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import android.util.Log;
import butterknife.Unbinder;


public class LoginActivity extends AppCompatActivity  implements OnClickListener, MyView.LoginView{
    private LoginPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Unbinder bind = ButterKnife.bind(this);
        presenter = new LoginPresenter(this);
    }
    @BindView(R.id.login_et_pwd)
    EditText et_pwd;
    @BindView(R.id.login_et_email)
    EditText et_email;
    @BindView(R.id.login_bt_login)
    Button bt_login;
    @BindView(R.id.login_bt_sign)
    Button bt_register;

    @OnClick({
            R.id.login_bt_login,
            R.id.login_bt_sign,
    })
    public void onClick(View view){
        switch(view.getId()){
            case R.id.login_bt_sign:
                //TODO:进入注册页面
                Log.d("调试","button");
                startActivity(new Intent(this, RegisterActivity.class));
                //finish();
                //提供后退箭头，不知道是否finish
                break;
            case R.id.login_bt_login:
                String email = et_email.getText().toString();
                String password = et_pwd.getText().toString();
                if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password)){
                    presenter.getData(email, password);
                    /*Only for test
                    SharedPreferences cache = getSharedPreferences("cache",MODE_WORLD_READABLE | MODE_WORLD_WRITEABLE | MODE_MULTI_PROCESS);
                    Editor editor = cache.edit();
                    editor.putString("Email",et_email.getText().toString());
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    */
                }
                else{
                    Toast.makeText(this, "账号或密码不能为空", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    @Override
    public void success(LoginBean loginBean) {
        Toast.makeText(this, loginBean.getMsg(), Toast.LENGTH_SHORT).show();
        if(loginBean.getMsg().equals("成功")){
            // TODO:航班信息存入Preferences
            SharedPreferences cache = getSharedPreferences("cache",MODE_WORLD_READABLE | MODE_WORLD_WRITEABLE | MODE_MULTI_PROCESS);
            Editor editor = cache.edit();
            editor.putString("Email",et_email.getText().toString());
            // GSON
            if(loginBean.getData().size()!=0){
                Gson gson = new Gson();
                String json = gson.toJson(loginBean);
                editor.putString(et_email.getText().toString()+"Flight",json);
            }

            editor.apply();
            //
            try {
                Thread.sleep(1000);
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void failed(int code) {
        Toast.makeText(this, "登录失败！请检查登录信息", Toast.LENGTH_SHORT).show();
    }

}
