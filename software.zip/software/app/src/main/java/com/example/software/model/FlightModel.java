package com.example.software.model;

import java.util.concurrent.TimeUnit;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;

public class FlightModel {
    //https://www.zhaoapi.cn/user/getUserInfo?uid=100
    public void getFlightData(String departure,String arrival,String number,String date,String account,String plane_id,int flag, final ModelCallBack.FlightCallBack callBack){
        //使用okhttp请求,添加拦截器时把下面代码解释
        OkHttpClient ok = new OkHttpClient.Builder()
                .connectTimeout(20000, TimeUnit.SECONDS)
                .writeTimeout(20000,TimeUnit.SECONDS)
                .readTimeout(20000,TimeUnit.SECONDS)
                .addInterceptor(new LoggingInterceptor())
                .build();

        //使用Retrofit结合RxJava，okhttp封装类的单例模式
        RetrofitUnitl.getInstance("http://114.115.172.245:8008/",ok)
                .setCreate(GetDataInterface.class)
                .flight(departure,arrival,number,date,account,plane_id,flag)
                .subscribeOn(Schedulers.io())               //请求完成后在io线程中执行
                .observeOn(AndroidSchedulers.mainThread())  //最后在主线程中执行

                //进行事件的订阅，使用Consumer实现
                .subscribe(new Consumer<FlightBean>() {
                    @Override
                    public void accept(FlightBean flightBean) throws Exception {
                        //请求成功时返回数据
                        callBack.success(flightBean);
                        System.out.println("m航班信息：" + flightBean.toString());
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        callBack.failed(throwable);
                    }
                });
    }
}
