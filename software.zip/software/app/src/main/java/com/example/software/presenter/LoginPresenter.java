package com.example.software.presenter;

import com.example.software.model.LoginBean;
import com.example.software.model.LoginModel;
import com.example.software.model.ModelCallBack;
import com.example.software.view.MyView;

public class LoginPresenter {
    LoginModel loginModel = new LoginModel();
    MyView.LoginView loginView;
    public LoginPresenter(MyView.LoginView loginView) {
        this.loginView = loginView;
    }

    public void getData(String tel, String pwd) {
        loginModel.getLoginData(tel,pwd, new ModelCallBack.LoginCallBack() {
            @Override
            public void success(LoginBean loginBean) {
                loginView.success(loginBean);
                //System.out.println("登录p数据："+loginBean.toString());
            }

            @Override
            public void failed(Throwable code) {
                System.out.println("登录p错误："+code);
            }
        });
    }
}
