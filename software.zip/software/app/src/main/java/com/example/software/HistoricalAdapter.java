package com.example.software;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


import com.example.software.model.LoginBean;
import android.content.Context;
import java.util.ArrayList;

public class HistoricalAdapter extends RecyclerView.Adapter<HistoricalAdapter.ViewHolder>{
    private ArrayList<LoginBean.DataBean> list;
    private Context context;
    private DeleteInterface deleteInterface;
    public HistoricalAdapter(Context context,ArrayList<LoginBean.DataBean> lists) {
        this.context = context;
        int flag;
        ArrayList<LoginBean.DataBean> tmp = new ArrayList<LoginBean.DataBean>();
        for(int i=0;i<lists.size();i++){
            flag = 0;
            for(int j=0;j<i;j++){
                if(lists.get(j).getId().equals(lists.get(i).getId())){
                    flag = 1;
                    break;
                }
            }
            if(flag==0){
                tmp.add(lists.get(i));
            }
        }
        this.list = tmp;
    }


    @Override
    public HistoricalAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.item_flight2 , parent ,false);
        return new HistoricalAdapter.ViewHolder(item);
    }

    public void buttonSetOnclick(DeleteInterface deleteInterface){

        this.deleteInterface=deleteInterface;
    }
    public interface DeleteInterface{

        public void onclick( View view,int position,String id);

    }


    @Override
    public void onBindViewHolder(HistoricalAdapter.ViewHolder holder,final int position) {
        String tmp1 = list.get(position).getDepart_time().split(" ")[1];
        String []split1 = tmp1.split(":");
        String tmp2 = list.get(position).getArrive_time().split(" ")[1];
        String []split2 = tmp2.split(":");
        String []split = list.get(position).getDepart_time().split("-");
        ((ViewHolder)holder).src.setText(list.get(position).getDeparture());
        ((ViewHolder)holder).dst.setText(list.get(position).getArrival());
        ((ViewHolder)holder).no.setText(list.get(position).getAirline()+" "+list.get(position).getNumber());
        ((ViewHolder)holder).port1.setText(list.get(position).getDpt_airport());
        ((ViewHolder)holder).port2.setText(list.get(position).getArv_airport());
        ((ViewHolder)holder).price.setText("￥ "+list.get(position).getPrice());
        ((ViewHolder)holder).start.setText(split1[0]+":"+split1[1]);
        ((ViewHolder)holder).end.setText(split2[0]+":"+split2[1]);
        ((ViewHolder)holder).date.setText("起飞时间:"+split[1]+"月"+split[2].split(" ")[0]+"日");

        if((split1[0]+split1[1]).compareTo(split2[0]+split2[1])>0){
            ((ViewHolder)holder).oneday.setText("+1天");
        }
        //((ViewHolder)holder).oneday.setText(list.get(position).getDeparture());
        ((ViewHolder)holder).late.setText("预测准点率:"+list.get(position).getDelay_rate());
        ((ViewHolder)holder).times.setText(list.get(position).getSpendtime()+" 分钟");
        ((ViewHolder)holder).deletes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(deleteInterface!=null){
                    deleteInterface.onclick(v,position,list.get(position).getId());
                }
            }
        });
    }


    public void setList(ArrayList<LoginBean.DataBean> list){
        int flag;
        ArrayList<LoginBean.DataBean> tmp = new ArrayList<LoginBean.DataBean>();
        for(int i=0;i<list.size();i++){
            flag = 0;
            for(int j=0;j<i;j++){
                if(list.get(j).getId().equals(list.get(i).getId())){
                    flag = 1;
                    break;
                }
            }
            if(flag==0){
                tmp.add(list.get(i));
            }
        }
        this.list = tmp;
        //Log.d("调试","adpter size:"+String.valueOf(this.list.size()));
    }


    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public LoginBean.DataBean getItem(int position){
        return list.get(position);
    }



    class ViewHolder extends RecyclerView.ViewHolder {
        TextView src;
        TextView dst;
        TextView no;
        TextView port1;
        TextView port2;
        TextView price;
        TextView start;
        TextView end;
        TextView oneday;
        TextView late;
        TextView times;
        TextView date;
        Button deletes;

        ViewHolder(View itemView) {
            super(itemView);

            start = itemView.findViewById(R.id.flight2_date1);
            src = itemView.findViewById(R.id.flight2_src);
            dst = itemView.findViewById(R.id.flight2_dst);
            no = itemView.findViewById(R.id.flight2_no);
            port1 = itemView.findViewById(R.id.flight2_port1);
            port2 = itemView.findViewById(R.id.flight2_port2);
            price = itemView.findViewById(R.id.flight2_price);
            end = itemView.findViewById(R.id.flight2_date2);
            oneday = itemView.findViewById(R.id.flight2_1day);
            late = itemView.findViewById(R.id.flight2_late);
            times = itemView.findViewById(R.id.flight2_time);
            date = itemView.findViewById(R.id.flight2_start);
            deletes = itemView.findViewById(R.id.flight2_bt);
        }

    }

}
