package com.example.software;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import com.example.software.model.FlightBean;
import com.example.software.presenter.FlightPresenter;
import com.example.software.view.MyView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import android.content.SharedPreferences.Editor;
import android.util.Log;

public class FlightActivity extends AppCompatActivity implements MyView.FlightView {
    private RecyclerView mRecyclerView;
    private MyRecyclerViewAdapter mAdapter;
    private List<FlightBean.DataBean> list = new ArrayList<FlightBean.DataBean>();
    private FlightPresenter presenter;
    private int mark;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight);
        //通过findViewById拿到RecyclerView实例
        Button bt = (Button) findViewById(R.id.flight_back);

        bt.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
           finish();
        }
        });

        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.addItemDecoration(new HorizontalDividerItemDecoration.Builder(this).build());
        //设置RecyclerView管理器
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        //初始化适配器
        mAdapter = new MyRecyclerViewAdapter(this,list);
        //设置适配器
        mRecyclerView.setAdapter(mAdapter);
        // 发起请求，获得FlightBean，初始化list
        presenter = new FlightPresenter(this);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        int mode = bundle.getInt("mode");
        Log.d("调试",String.valueOf(mode));
        if(mode==1){
            //TODO:航班编号查询
            String no = bundle.getString("num");
            String date = bundle.getString("date");
            presenter.getData("None", "None",no,date,"default","default",1);
        }
        else{
            //TODO:目的地查询
            String src = bundle.getString("src");
            String dst = bundle.getString("dst");
            String date = bundle.getString("date");
            presenter.getData(src, dst, "0",date,"default","default",0);
        }
        mAdapter.buttonSetOnclick(new MyRecyclerViewAdapter.ButtonInterface() {
            @Override
            public void onclick(View view, int position, String id) {
                SharedPreferences cache = getSharedPreferences("cache",MODE_WORLD_READABLE | MODE_WORLD_WRITEABLE | MODE_MULTI_PROCESS);
                String account = cache.getString("Email","default");
                //TODO:标记，写入SharedPreferences
                mark = position;
                presenter.getData("default","default","default","default",account,id,2);

            }
        });
    }


    @Override
    public void success(FlightBean flightBean) {
        //Toast.makeText(this, flightBean.getMsg(), Toast.LENGTH_SHORT).show();
        if(flightBean.getMsg().equals("查询成功")){
            this.list.addAll(flightBean.data);
            mAdapter.setList(this.list);
            mAdapter.notifyDataSetChanged();
        }
        else if(flightBean.getMsg().equals("标记成功")){
            Gson gson = new Gson();
            SharedPreferences cache = getSharedPreferences("cache",MODE_WORLD_READABLE | MODE_WORLD_WRITEABLE | MODE_MULTI_PROCESS);
            String usr = cache.getString("Email","");
            String json = cache.getString(usr+"Mark","");
            List<FlightBean.DataBean> save = gson.fromJson(json,new TypeToken<List<FlightBean.DataBean>>(){}.getType());
            if(save==null){
                save = new ArrayList<FlightBean.DataBean>();
            }
            save.add(mAdapter.getItem(mark));
            Editor editor = cache.edit();
            String json2 = gson.toJson(save);
            editor.putString(usr+"Mark",json2);
            editor.apply();
            Toast.makeText(this,"标记成功",Toast.LENGTH_SHORT).show();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    notifacate(mAdapter.getItem(mark));
                }
            }).start();
        }
    }
    @Override
    public void failed(int code) {
        Toast.makeText(this, "网络连接失败", Toast.LENGTH_SHORT).show();
    }

    public void notifacate(FlightBean.DataBean data){
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(FlightActivity.this);
        mBuilder.setContentTitle("禁运事项")//设置通知栏标题
                .setContentText("您选择的由"+data.getDeparture()+"飞往"+data.getArrival()
                +"的航班已标记成功，以下为航班的禁运事项飞机禁带物品：枪支（含各种仿真玩具枪、枪型打火机胶其它各种类型的带有攻击型的武器）弹药、军械、警械、管制刀具、爆炸物品、易燃易爆物品、剧毒物品、放射性物品、腐蚀性物品、危险溶液及国家规定的其它禁运物品。")
                .setTicker("测试通知来啦") //通知首次出现在通知栏，带上升动画效果的
                .setWhen(System.currentTimeMillis())//通知产生的时间，会在通知信息里显示，一般是系统获取到的时间
                .setPriority(Notification.PRIORITY_DEFAULT) //设置该通知优先级
//  .setAutoCancel(true)//设置这个标志当用户单击面板就可以让通知将自动取消
                .setOngoing(false)//ture，设置他为一个正在进行的通知。他们通常是用来表示一个后台任务,用户积极参与(如播放音乐)或以某种方式正在等待,因此占用设备(如一个文件下载,同步操作,主动网络连接)
                .setDefaults(Notification.DEFAULT_VIBRATE)//向通知添加声音、闪灯和振动效果的最简单、最一致的方式是使用当前的用户默认设置，使用defaults属性，可以组合
                //Notification.DEFAULT_ALL  Notification.DEFAULT_SOUND 添加声音 // requires VIBRATE permission
                .setSmallIcon(R.mipmap.logo);//设置通知小ICON


        Intent intent = new Intent(FlightActivity.this,BanActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(FlightActivity.this, 0, intent, 0);
        mBuilder.setContentIntent(pendingIntent);


        Notification notification = mBuilder.build();
        notification.flags = Notification.FLAG_AUTO_CANCEL;

        manager.notify(1,notification);
    }

}
