package com.example.software.model;

public class RegBean {
    private int status;
    private String msg;

    public int getStatus(){
        return status;
    }
    public String getMsg(){
        return msg;
    }

}
