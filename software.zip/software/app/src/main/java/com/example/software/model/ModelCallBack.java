package com.example.software.model;

import com.example.software.model.FlightBean;
import com.example.software.model.LoginBean;
import com.example.software.model.RegBean;

public interface ModelCallBack {
    public interface LoginCallBack{
        //登录时，数据获取成功的方法，返回一个值表示登陆成功
        public void success(LoginBean loginBean);
        //登录时，数据获取失败的方法，返回一个int值响应码表示登陆失败
        public void failed(Throwable code);
    }

    public interface RegCallBack {
        //注册时，数据获取成功的方法，返回一个值表示登陆成功
        public void success(RegBean regBean);
        //注册时，数据获取失败的方法，返回一个int值响应码表示登陆失败
        public void failed(Throwable code);
    }

    //查询
    public interface FlightCallBack{
        void success(FlightBean flightBean);
        void failed(Throwable code);
    }
    public interface MarkedCallBack{
        void success(MarkedBean markedBean);
        void failed(Throwable code);
    }




}
