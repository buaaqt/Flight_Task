package com.example.software.presenter;

import com.example.software.model.FlightBean;
import com.example.software.model.FlightModel;
import com.example.software.model.ModelCallBack;
import com.example.software.view.MyView;

public class FlightPresenter {
    FlightModel flightModel = new FlightModel();
    MyView.FlightView flightView;
    public FlightPresenter(MyView.FlightView flightView) {
        this.flightView = flightView;
    }

    public void getData(String departure,String arrival,String number,String date,String account,String plane_id,int flag) {
        flightModel.getFlightData(departure,arrival,number,date,account,plane_id,flag, new ModelCallBack.FlightCallBack() {
            @Override
            public void success(FlightBean flightBean) {
                flightView.success(flightBean);
                //System.out.println("航班p数据："+flightBean.toString());
            }

            @Override
            public void failed(Throwable code) {
                System.out.println("航班p错误："+code);
            }
        });
    }
}
