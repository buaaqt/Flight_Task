package com.example.software;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import com.example.software.model.FlightBean;
import java.util.List;
import java.util.ArrayList;
import android.support.annotation.NonNull;

import com.example.software.model.FlightBean;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {
    private List<FlightBean.DataBean> list;
    private Context context;
    private ButtonInterface buttonInterface;
    public MyRecyclerViewAdapter(Context context,List<FlightBean.DataBean> list) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.item_flight , parent ,false);
        return new MyRecyclerViewAdapter.ViewHolder(item);
        //View view = LayoutInflater.from(context.inflate(R.layout.item_flight, parent, false);
        //return new ViewHolder(view);

    }
    public void buttonSetOnclick(ButtonInterface buttonInterface){

        this.buttonInterface=buttonInterface;

    }

    public interface ButtonInterface{

        public void onclick( View view,int position,String id);

    }

    @Override
    public void onBindViewHolder(MyRecyclerViewAdapter.ViewHolder holder, final int position) {
        String tmp1 = list.get(position).getDepart_time().split(" ")[1];
        String []split1 = tmp1.split(":");
        String tmp2 = list.get(position).getArrive_time().split(" ")[1];
        String []split2 = tmp2.split(":");
        String []split = list.get(position).getDepart_time().split("-");
        ((ViewHolder)holder).src.setText(list.get(position).getDeparture());
        ((ViewHolder)holder).dst.setText(list.get(position).getArrival());
        ((ViewHolder)holder).no.setText(list.get(position).getAirline()+" "+list.get(position).getNumber());
        ((ViewHolder)holder).port1.setText(list.get(position).getDpt_airport());
        ((ViewHolder)holder).port2.setText(list.get(position).getArv_airport());
        ((ViewHolder)holder).price.setText("￥ "+list.get(position).getPrice());
        ((ViewHolder)holder).start.setText(split1[0]+":"+split1[1]);
        ((ViewHolder)holder).end.setText(split2[0]+":"+split2[1]);
        ((ViewHolder)holder).date.setText("起飞时间:"+split[1]+"月"+split[2].split(" ")[0]+"日");
        if((split1[0]+split1[1]).compareTo(split2[0]+split2[1])>0){
            ((ViewHolder)holder).oneday.setText("+1天");
        }
        //((ViewHolder)holder).oneday.setText(list.get(position).getDeparture());
        ((ViewHolder)holder).late.setText("预测准点率:"+list.get(position).getDelay_rate());
        ((ViewHolder)holder).times.setText(list.get(position).getSpendtime()+" 分钟");
        // 航空公司和编号
        ((ViewHolder)holder).mark.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(buttonInterface!=null){
                    buttonInterface.onclick(v,position,list.get(position).getId());
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public FlightBean.DataBean getItem(int position){
        return list.get(position);
    }

    public void setList(List<FlightBean.DataBean> list){
        this.list = list;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView src;
        TextView dst;
        TextView no;
        TextView port1;
        TextView port2;
        TextView price;
        TextView start;
        TextView end;
        TextView oneday;
        TextView late;
        TextView times;
        TextView date;
        Button mark;

        ViewHolder(View itemView) {
            super(itemView);

            start = itemView.findViewById(R.id.flight_date1);
            src = itemView.findViewById(R.id.flight_src);
            dst = itemView.findViewById(R.id.flight_dst);
            no = itemView.findViewById(R.id.flight_no);
            port1 = itemView.findViewById(R.id.flight_port1);
            port2 = itemView.findViewById(R.id.flight_port2);
            price = itemView.findViewById(R.id.flight_price);
            end = itemView.findViewById(R.id.flight_date2);
            oneday = itemView.findViewById(R.id.flight_1day);
            late = itemView.findViewById(R.id.flight_late);
            times = itemView.findViewById(R.id.flight_time);
            date = itemView.findViewById(R.id.flight_start);
            mark = itemView.findViewById(R.id.flight_bt);

        }

    }


}
