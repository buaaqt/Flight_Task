package com.example.software;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.view.View.OnClickListener;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.widget.Toast;
import android.widget.TextView;
import android.app.DatePickerDialog.OnDateSetListener;
import org.w3c.dom.Text;
import java.util.Locale;
import java.util.Calendar;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import android.widget.CompoundButton;
import com.zaaach.citypicker.CityPicker;
import com.zaaach.citypicker.CityPicker.*;
import com.zaaach.citypicker.adapter.OnPickListener;
import com.zaaach.citypicker.model.HotCity;
import com.zaaach.citypicker.model.LocatedCity;
import com.zaaach.citypicker.model.City;



public class ExploreFragment extends Fragment{

    int choose;
    EditText et_src;
    EditText et_dst;

    public static ExploreFragment newInstance(String param1, String param2) {
        ExploreFragment fragment = new ExploreFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_explore, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ImageView imageView = (ImageView) getActivity().findViewById(R.id.imageView3);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final TextView dateText1 = (TextView) getActivity().findViewById(R.id.ex_et_date);
        final TextView dateText2 = (TextView) getActivity().findViewById(R.id.ex_et_date2);
        et_src = (EditText) getActivity().findViewById(R.id.ex_et_src);
        et_dst = (EditText) getActivity().findViewById(R.id.ex_et_dst);
        dateText1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance(Locale.CHINA);
                new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {                      //选择日期点击OK后执行
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        int month = monthOfYear+1;
                        String months = String.valueOf(month);
                        if(month<=10){
                            months = "0"+months;
                        }
                        dateText1.setText(year+"-"+months+"-"+dayOfMonth);
                    }
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();

            }
        });
        dateText2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance(Locale.CHINA);
                new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {                      //选择日期点击OK后执行
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        int month = monthOfYear+1;
                        String months = String.valueOf(month);
                        if(month<=10){
                            months = "0"+months;
                        }
                        dateText2.setText(year+"-"+months+"-"+dayOfMonth);
                    }
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();

            }
        });

        final EditText src = (EditText) getActivity().findViewById(R.id.ex_et_src);
        final EditText dst = (EditText) getActivity().findViewById(R.id.ex_et_dst);
        final List<HotCity> hotCities = new ArrayList<>();
        hotCities.add(new HotCity("北京", "北京", "101010100"));
        hotCities.add(new HotCity("上海", "上海", "101020100"));
        hotCities.add(new HotCity("广州", "广东", "101280101"));
        hotCities.add(new HotCity("深圳", "广东", "101280601"));
        hotCities.add(new HotCity("天津", "天津", "101030100"));
        hotCities.add(new HotCity("成都", "四川", "101270101"));
        hotCities.add(new HotCity("南京", "江苏", "101190101"));
        hotCities.add(new HotCity("合肥", "安徽", "101220101"));
        hotCities.add(new HotCity("青岛", "山东", "101120201"));
        hotCities.add(new HotCity("武汉", "湖北", "101200101"));
        hotCities.add(new HotCity("重庆", "重庆", "101040100"));
        hotCities.add(new HotCity("长沙", "湖南", "101250101"));
        hotCities.add(new HotCity("厦门", "福建", "101230201"));
        hotCities.add(new HotCity("西安", "陕西", "101110101"));
        src.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("调试","Src clicked");
                choose = 0;
                CityPicker.from(getActivity()) //activity或者fragment
                        .enableAnimation(false)	//启用动画效果，默认无
                        .setAnimationStyle(R.style.DefaultCityPickerAnimation)	//自定义动画
                        .setLocatedCity(new LocatedCity("北京", "北京", "101010100"))  //APP自身已定位的城市，传null会自动定位（默认）
                        .setHotCities(hotCities)	//指定热门城市
                        .setOnPickListener(new OnPickListener() {
                            @Override
                            public void onPick(int position, City data) {
                                //Toast.makeText(getApplicationContext(), data.getName(), Toast.LENGTH_SHORT).show();
                                et_src.setText(data.getName());
                            }

                            @Override
                            public void onCancel(){
                                //Toast.makeText(getApplicationContext(), "取消选择", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onLocate() {
                                //定位接口，需要APP自身实现，这里模拟一下定位

                            }
                        })
                        .show();
            }
        });
        dst.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                choose = 1;
                CityPicker.from(getActivity()) //activity或者fragment
                        .enableAnimation(false)	//启用动画效果，默认无
                        .setAnimationStyle(R.style.DefaultCityPickerAnimation)	//自定义动画
                        .setLocatedCity(new LocatedCity("北京", "北京", "101010100"))  //APP自身已定位的城市，传null会自动定位（默认）
                        .setHotCities(hotCities)	//指定热门城市
                        .setOnPickListener(new OnPickListener() {
                            @Override
                            public void onPick(int position, City data) {
                                //Toast.makeText(getApplicationContext(), data.getName(), Toast.LENGTH_SHORT).show();
                                et_dst.setText(data.getName());
                            }

                            @Override
                            public void onCancel(){
                                //Toast.makeText(getApplicationContext(), "取消选择", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onLocate() {
                                //定位接口，需要APP自身实现，这里模拟一下定位

                            }
                        })
                        .show();
            }
        });



        Button bt_que1 = (Button) getActivity().findViewById(R.id.ex_bt_que1);
        bt_que1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO:根据航班编号进行查询，进入新的查询页面
                EditText et_num = (EditText) getActivity().findViewById(R.id.ex_et_num);
                TextView et_date2 = (TextView) getActivity().findViewById(R.id.ex_et_date2);
                String number = et_num.getText().toString();
                String date = et_date2.getText().toString();
                if (!TextUtils.isEmpty(number) && !TextUtils.isEmpty(date)){
                    Intent intent = new Intent(getActivity(), FlightActivity.class);
                    intent.putExtra("num",number);
                    intent.putExtra("date",date);
                    intent.putExtra("mode",1);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getActivity(), "查询信息不能为空", Toast.LENGTH_SHORT).show();
                }

            }
        });
        Button bt_que2 = (Button) getActivity().findViewById(R.id.ex_bt_que2);
        bt_que2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO:根据出发地、目的地和时间进行查询，进入新的查询页面
                TextView et_date = (TextView) getActivity().findViewById(R.id.ex_et_date);
                String src = et_src.getText().toString();
                String dst = et_dst.getText().toString();
                String date = et_date.getText().toString();
                if (!TextUtils.isEmpty(src) && !TextUtils.isEmpty(date) && !TextUtils.isEmpty(dst)){
                    Intent intent = new Intent(getActivity(), FlightActivity.class);
                    intent.putExtra("src",src);
                    intent.putExtra("dst",dst);
                    intent.putExtra("date",date);
                    intent.putExtra("mode",2);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getActivity(), "查询信息不能为空", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    /*
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        Log.d("调试","fragment-onActRes");
        if (requestCode == CityListSelectActivity.CITY_SELECT_RESULT_FRAG) {
            if (resultCode == -1) {
                if (data == null) {
                    return;
                }
                Bundle bundle = data.getExtras();

                CityInfoBean cityInfoBean = (CityInfoBean) bundle.getParcelable("cityinfo");

                if (null == cityInfoBean) {
                    return;
                }
                String []tmp = cityInfoBean.getName().split("市");
                String city = tmp[0];
                if(choose==0){
                    et_src.setText(city);
                }
                else{
                    et_dst.setText(city);
                }
                Log.d("调试",city);
            }
        }
    }*/

}
